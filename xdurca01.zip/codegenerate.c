/* **************************** codegenerate.c ************************************ */
/* Soubor:             codegenerate.c - Generovanie kodu a jeho vykonanie      */
/* Kodovani:            UTF-8                                                 */
/* Datum:               11.2014                                               */
/* Predmet:             Formalni jazyky a prekladace (IFJ)                    */
/* Projekt:             Implementace interpretu jazyka IFJ14                  */
/* Varianta zadani:     a/2/II                                                */
/* Titul,Autori, login:         Ing. Natalya Loginova   xlogin00              */
/*                              Jindrich Dudek          xdudek04              */
/*                              Norbert Durcansky       xdurca01              */
/*                              Jan Jusko               xjusko00              */
/*                              Jiøí Dostál             xdosta40              */
/* ****************************************************************************/



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "scaner.h"
#include "parser.h"
#include "string.h"
#include "err.h"
#include "ial.h"
#include "stack.h"
#include "precedent.h"
#include "codegenerate.h"

///Hlavicka sa mozno zmeni este
int generate_inst(char *A,float B,float C,int CODE)
{

  /*
INS_Tape *Instruction=(INS_Tape*)malloc(sizeof(INS_Tape));

Instruction->a=(char*)malloc(sizeof(char)*length(A));
strcpy(Instruction->a,A);
Instruction->CODE=LENGTH;
*/

/*
if(Instruction->CODE==LENGTH)
{
    printf("length %i\n",length(Instruction->a));
}*/
    return 0;
}






