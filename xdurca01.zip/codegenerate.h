int generate_inst(char*,float,float,int);


typedef struct {
char *a;
float b;
int CODE;
}INSTape;
