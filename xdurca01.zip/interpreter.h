
struct record *temp;
char *globalne_pole;
float hodnota;
char* tempstr;
