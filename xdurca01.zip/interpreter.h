#ifndef INTERPRETER_H_
#define INTERPRETER_H_
struct record *temp;
char *globalne_pole;
float hodnota;
float hodnota3;
float hodnota4;
char* tempstr;
float  hodnota2;

#endif
