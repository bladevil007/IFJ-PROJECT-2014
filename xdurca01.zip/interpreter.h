
struct record *temp;
char *globalne_pole;
float hodnota;
float hodnota3;
float hodnota4;
char* tempstr;
float  hodnota2;
